package com.bluespringsusa.bluespringsusa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
